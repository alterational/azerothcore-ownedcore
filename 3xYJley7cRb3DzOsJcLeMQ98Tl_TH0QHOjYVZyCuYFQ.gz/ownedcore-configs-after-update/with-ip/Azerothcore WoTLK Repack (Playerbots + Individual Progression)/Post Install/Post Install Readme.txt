
The DBC and MPQ files here are required to be installed after you install the repack.
The addons here are optional but can enhance your experience.

Client Addons = Those are client addons. Each module contains a subfolder and that subfolder is the addon folder that you should copy/paste into your client's "Interface\AddOns" folder.
Client MPQ = Those MPQ files go to your client's "data" folder.
DBCs =	The DBC files here go to your repack's "data/dbc" folder. Replace when prompted.












